def suma(a,b):
    return a+b
resultado = suma(2,5)
print("El resultado es: ", resultado)

#Este ejercicio muestra la importancia del return 
#pues al imprimir la respuesta esta está vacia
#si no se usa el return

def sumar(a,b):
    print(a+b)

x = sumar(3,7)
print("x vale: ",x)