
coders = ["Isabella", "Maria", "Andres", "Hector", "Melanie"]

for index, coder in enumerate (coders):
    print(f"coder {coder} esta en el index {index}")