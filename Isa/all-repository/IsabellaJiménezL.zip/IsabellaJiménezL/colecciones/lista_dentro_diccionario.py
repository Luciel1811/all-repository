#Esto es una lista con diccionarios 
coders = [{
    "nombre": "Isabella",
    "apellido": "Jiménez",
    "edad": 20,
    "estatura": 169,
    "peso": 64
},
{
    "nombre": "Nelson",
    "apellido": "Salsedo",
    "edad": 20,
    "estatura": 178,
    "peso": 80
},
{
    "nombre": "Melanie",
    "apellido": "Fernandez",
    "edad": 20,
    "estatura": 164,
    "peso": 57
}]

for i in range(len(coders)):
    print(coders[i])