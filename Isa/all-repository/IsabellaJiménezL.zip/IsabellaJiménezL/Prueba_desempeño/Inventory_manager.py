from utils_4 import *

show_menu(inventory)